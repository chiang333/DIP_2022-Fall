## COMPILE
- g++ -std=c++14 1.cpp -o restoration

## EXECUTE
- ./restoration

## INPUT FILE
./ `input1.bmp` `input2.bmp`

## OUTPUT FILE
./`output1.bmp`
./`output2.bmp`
